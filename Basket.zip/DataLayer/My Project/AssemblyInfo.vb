﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Управление общими сведениями о сборке осуществляется с помощью 
' набора атрибутов. Измените значения этих атрибутов для изменения сведений,
' связанных с этой сборкой.

' Проверка значений атрибутов сборки
<Assembly: AssemblyTitle("DataLayer")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("DataLayer")>
<Assembly: AssemblyCopyright("Copyright ©  2022")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Следующий GUID служит для идентификации библиотеки типов typelib, если этот проект видим для COM
<Assembly: Guid("8d626ccc-2f91-4eb9-a81c-5fec62b7112d")>

' Сведения о версии сборки состоят из указанных ниже четырех значений:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' Можно задать все значения или принять номер сборки и номер редакции по умолчанию, 
' используя "*", как показано ниже:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
