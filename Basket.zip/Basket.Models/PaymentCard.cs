﻿namespace Basket.Models
{
    public class PaymentCard
    {
        public string CardNumber { get; set; }

        public string Date { get; set; }

        public string Cvv { get; set; }

    }
}
