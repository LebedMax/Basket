﻿using Basket.BusinessLayer;
using System.Web.Mvc;

namespace GamesMarket.Controllers
{
    public class PurchaseController : Controller
    {
        private readonly ICartService _cartService;

        public PurchaseController()
        {
            _cartService = new CartService();
        }

        public ActionResult Index(string session)
        {
            var basketProducts = _cartService.GetAllEntries(session);

            return View(basketProducts);
        }
    }
}