﻿using System.Data.Entity;
using Basket.Models;

namespace Basket.DataAccess
{
    public class AppDBContent : DbContext
    {
        public AppDBContent(string connectionString)
            :base(connectionString)
        {

        }

        public DbSet<Game> Games { get; set; }
        public DbSet<Order> Order { get; set; }

        public DbSet<GameDetail> gameDetails { get; set; }

    }
}
