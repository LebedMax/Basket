﻿using Basket.DataAccess;
using System.Collections.Generic;


namespace Basket.Models.Repository
{
    //public class Repository
    //{
    //    private AppDBContent context = new AppDBContent();

    //    public IEnumerable<Game> Games
    //    {
    //        get { return context.Games; }
    //    }
    //}
    
}