﻿using Basket.BusinessLayer;
using Basket.DataAccess;
using Basket.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Basket.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["AppDBContent"].ConnectionString;

            using (var context = new AppDBContent(connectionString))
            {
                var entity = context.Games.FirstOrDefault();
            }



        }
    }
}
