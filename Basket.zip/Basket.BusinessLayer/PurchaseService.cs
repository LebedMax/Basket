﻿using Basket.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basket.BusinessLayer
{
    public class PurchaseService : IPurchaseService
    {
        private IPaymentService _paymentService;

        private ICartService _cartService;

        public PurchaseService()
        {
            _paymentService = new PaymentService();

            _cartService = new CartService();
        }

        public void Purchase(List<CartLine> cart, PaymentCard card, Buyer buyer)
        {
            var overalPrice = _cartService.OveralPrice(cart);

            ValidateCard(card);

            ValidateBuyer(buyer);

            _paymentService.Pay(card, overalPrice);
        }

        private void ValidateBuyer(Buyer buyer)
        {
            throw new ValidationException("dsfd");
          //  Regex regex =new Regex(@)

        }

        private void ValidateCard(PaymentCard card)
        {
            throw new NotImplementedException();
        }
    }
}
