﻿using Basket.Models;
using System.Collections.Generic;

namespace Basket.BusinessLayer
{
    interface IPurchaseService
    {
        void Purchase(List<CartLine> cart, PaymentCard card, Buyer buyer);
    }
}
